package com.sample.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleApp3Application {

	public static void main(String[] args) {
		SpringApplication.run(SampleApp3Application.class, args);
	}

}
