package com.sample.app.model;

import lombok.Data;

@Data
public class LoginInput {

	private String userName;
	private String password;
}
